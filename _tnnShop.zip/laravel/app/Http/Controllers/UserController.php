<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserController extends Controller
{
    public function login(Request $request)
    {
        $credentials = $this->readAccounts('user');
        if (!is_array($credentials)) {
            return redirect()->route('user.login')->with('error', 'Không thể đọc dữ liệu tài khoản.');
        }

        foreach ($credentials as $user) {
            // Kiểm tra nếu $user là một mảng trước khi truy cập các phần tử
            if (is_array($user) && $user['username'] === $request->username && $user['password'] === $request->password) 
            {
                session(['role' => 'user']);
                return redirect()->route('user.home');
            }
        }

        return redirect()->route('user.login')->with('error', 'Sai tài khoản hoặc mật khẩu!');
    }

    private function readAccounts($role)
    {
        $file = storage_path('app/accounts.txt'); 
        $accounts = [];

        if (file_exists($file)) {
            $lines = file($file, FILE_IGNORE_NEW_LINES);
            foreach ($lines as $line) {
                list($username, $password, $userRole) = explode('|', $line);
                if (trim($userRole) === $role) {
                    $accounts[] = ['username' => trim($username), 'password' => trim($password)];
                }
            }
        } else {
            return ['error' => 'File account.txt không tồn tại.'];
        }

        return $accounts;
    }

    public function loginForm()
    {
        return view('index'); 
    }

    public function home()
    {
        return view('home'); 
    }
}

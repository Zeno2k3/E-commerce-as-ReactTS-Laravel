<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminController extends Controller
{
    //login by readAccounts accounts.txt
    public function login(Request $request)
    {
        $credentials = $this->readAccounts('admin');

        foreach ($credentials as $user) {
            if ($user['username'] === $request->username && $user['password'] === $request->password) 
            {
                session(['role' => 'admin']);
                return redirect()->route('admin.dashboard');
            }
        }

        return redirect()->route('admin.login')->with('error', 'Sai tài khoản hoặc mật khẩu!');
    }

    private function readAccounts($role)
    {
        $file = storage_path('app/account.txt'); 
        $accounts = [];

        if (file_exists($file)) 
        {
            $lines = file($file, FILE_IGNORE_NEW_LINES);
            foreach ($lines as $line) {
                list($username, $password, $userRole) = explode('|', $line);
                if (trim($userRole) === $role) 
                {
                    $accounts[] = ['username' => trim($username), 'password' => trim($password)];
                }
            }
        } 
        else 
        {
            return ['error' => 'File account.txt không tồn tại.'];
        }

        return $accounts;
    }

    //show form LoginForm
    public function loginForm()
    {
        return view('index'); 
    }

    public function dashboard()
    {
        if (session('role') !== 'admin') 
        {
            return redirect('/')->with('error', '');
        }

        return view('dashboard'); 
    }
}

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập thất bại</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Tự động quay lại trang index sau 10 giây
        setTimeout(function() {
            window.location.href = "<?php echo e(route('index')); ?>";
        }, 10000);

        // Chuyển hướng ngay lập tức khi nhấn nút
        function goBackNow() {
            window.location.href = "<?php echo e(route('index')); ?>";
        }
    </script>
</head>
<body class="d-flex justify-content-center align-items-center vh-100" style="background-color: #0d6efd;">
    <div class="text-center p-4 border border-danger rounded bg-danger-subtle text-danger shadow">
        <h2 class="fw-bold">Đăng nhập thất bại</h2>
        <p class="mb-2">Tài khoản hoặc mật khẩu không đúng. Vui lòng thử lại.</p>
        <p class="mb-3">Trang sẽ tự động chuyển về trang đăng nhập sau <b>10 giây</b>.</p>
        <button class="btn btn-danger px-4" onclick="goBackNow()">Quay lại ngay</button>
    </div>
</body>
</html>
<?php /**PATH C:\Users\Admin\_tnnShop\laravel\resources\views/error.blade.php ENDPATH**/ ?>
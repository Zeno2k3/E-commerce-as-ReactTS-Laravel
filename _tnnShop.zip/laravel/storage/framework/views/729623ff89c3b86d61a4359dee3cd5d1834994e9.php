<h2>Chào mừng bạn đến trang Dashboard</h2>
<a href="<?php echo e(route('login')); ?>">Đăng xuất</a><?php /**PATH C:\Users\Admin\_tnnShop\laravel\resources\views/login.blade.php ENDPATH**/ ?>
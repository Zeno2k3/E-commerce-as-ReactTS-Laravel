<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
</head>
<body class="flex items-center justify-center min-h-screen bg-blue-900">

    <!-- Màn hình chọn quyền -->
    <div id="role-selection" class="bg-gray-800 p-8 rounded-2xl shadow-xl w-96 text-center opacity-0">
        <h2 class="text-white text-2xl font-bold mb-6">Chọn quyền đăng nhập</h2>
        <button onclick="showLogin('Admin')" class="w-full p-3 mb-4 text-white bg-red-600 rounded-lg hover:bg-red-500 transition-transform transform hover:scale-105">Admin</button>
        <button onclick="showLogin('User')" class="w-full p-3 text-white bg-green-600 rounded-lg hover:bg-green-500 transition-transform transform hover:scale-105">User</button>
    </div>

    <!-- Form đăng nhập Admin -->
    <div id="admin-login-box" class="bg-gray-800 p-8 rounded-2xl shadow-xl w-96 opacity-0 hidden">
        <h2 class="text-white text-2xl font-bold text-center mb-6">Admin Login</h2>
        <form action="{{ route('admin.login.submit') }}" method="POST">
            @csrf
            <input type="text" name="username" placeholder="Username" class="w-full p-3 mb-4 text-white bg-gray-700 rounded-lg focus:ring-2 focus:ring-blue-400">
            <input type="password" name="password" placeholder="Password" class="w-full p-3 mb-4 text-white bg-gray-700 rounded-lg focus:ring-2 focus:ring-blue-400">
            <button type="submit" class="w-full p-3 text-white bg-blue-600 rounded-lg hover:bg-blue-500 transition-transform transform hover:scale-105">Login</button>
        </form>
        @if(session('error'))
            <p style="color: red">{{ session('error') }}</p>
        @endif  
    </div>

    <!-- Form đăng nhập User -->
    <div id="user-login-box" class="bg-gray-800 p-8 rounded-2xl shadow-xl w-96 opacity-0 hidden">
        <h2 class="text-white text-2xl font-bold text-center mb-6">User Login</h2>
        <form action="{{ route('user.login.submit') }}" method="POST">
            @csrf
            <input type="text" name="username" placeholder="Username" class="w-full p-3 mb-4 text-white bg-gray-700 rounded-lg focus:ring-2 focus:ring-blue-400">
            <input type="password" name="password" placeholder="Password" class="w-full p-3 mb-4 text-white bg-gray-700 rounded-lg focus:ring-2 focus:ring-blue-400">
            <button type="submit" class="w-full p-3 text-white bg-blue-600 rounded-lg hover:bg-blue-500 transition-transform transform hover:scale-105">Login</button>
        </form>
        @if(session('error'))
            <p style="color: red">{{ session('error') }}</p>
        @endif  
    </div>

    <script>
        gsap.to("#role-selection", { opacity: 1, y: -20, duration: 1, ease: "power2.out" });

        function showLogin(role) {
            gsap.to("#role-selection", { opacity: 0, y: 20, duration: 0.5, ease: "power2.in", onComplete: function() {
                document.getElementById("role-selection").classList.add("hidden");
                if(role === "Admin") {
                    document.getElementById("admin-login-box").classList.remove("hidden");
                    gsap.to("#admin-login-box", { opacity: 1, y: -20, duration: 1, ease: "power2.out" });
                } else {
                    document.getElementById("user-login-box").classList.remove("hidden");
                    gsap.to("#user-login-box", { opacity: 1, y: -20, duration: 1, ease: "power2.out" });
                }
            }});
        }
    </script>

</body>
</html>
